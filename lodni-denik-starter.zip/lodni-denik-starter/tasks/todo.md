# tasks/todo.md — Rodinný lodní deník

## Fáze 1: Setup
- [ ] Next.js projekt inicializován (App Router + TypeScript)
- [ ] Tailwind v4 + shadcn/ui (`npx shadcn@latest init -t next`)
- [ ] CLAUDE.md a BRAND_MANUAL.md v rootu
- [ ] Fonty (Fraunces, DM Sans, JetBrains Mono) v layout.tsx
- [ ] Design tokeny z BRAND_MANUAL.md v globals.css
- [ ] .env.example vytvořen, .env v .gitignore
- [ ] Supabase projekt založen, klíče v .env
- [ ] Git repo + Vercel deploy (testovací URL)

## Fáze 2: Databáze + auth
- [ ] Schéma: Trip, Entry, Photo (viz CLAUDE.md)
- [ ] RLS policies (zápis vlastník, čtení přes share_token)
- [ ] Storage bucket na fotky (ne veřejný, signed URLs)
- [ ] Přihlášení přes Google (Supabase Auth provider)

## Fáze 3: Jádro appky
- [ ] Layout — header + navigace (BRAND_MANUAL)
- [ ] Leaflet + OSM/Mapy.com podklad + OpenSeaMap overlay, piny + trasa (vlastní markery)
- [ ] Seznam výprav + detail výpravy
- [ ] Timeline zastávek
- [ ] Přidání zastávky z fotek (EXIF → GPS/čas → Nominatim název)
- [ ] Upload fotek + náhledy + lightbox
- [ ] Ruční doťuknutí pinu (když fotka nemá GPS)
- [ ] Veřejné sdílení přes share_token (read-only)

## Fáze 4: Kvalita
- [ ] Responzivita (mobile-first)
- [ ] Prázdné + loading stavy
- [ ] Lighthouse Accessibility ≥ 90, Performance ≥ 85
- [ ] /security-review

## Fáze 5 (později): Vychytávky
- [ ] „Jsme tady teď" — živý pin (jen po přihlášení, ne na veřejném odkazu)
- [ ] AIS vrstva — lodě v okolí (AISstream.io / VesselAPI)

## Review
_(sem Claude Code píše shrnutí po dokončení fází)_
